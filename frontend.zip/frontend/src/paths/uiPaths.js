const UiPaths = {
    auth:'/auth',
    task:'/task'
  };
  
  export default UiPaths;